---
version: "superdesign-alpha"
name: "Aerial Glass Wayfinder"
description: "White-dominant editorial travel system built on an aerial-photo hero, rounded photo-tile grids, a deep-teal ink for headings, and a single black band interruption carrying a marquee and a full-bleed destination card."
colors:
  background: "#FFFFFF"
  surface-dark-band: "#000000"
  text-primary: "#033D4A"
  text-secondary: "#404040"
  text-on-dark: "#FFFFFF"
  link: "#0000EE"
  accent-water: "#60C0D8"
typography:
  display-lg:
    fontFamily: "Cal Sans"
    fontSize: "92px"
    fontWeight: 600
    lineHeight: "1.2"
    letterSpacing: "-1.8px"
  headline-md:
    fontFamily: "Cal Sans"
    fontSize: "36px"
    fontWeight: 400
    lineHeight: "1.2"
  body-md:
    fontFamily: "Inter"
    fontSize: "20px"
    fontWeight: 500
    lineHeight: "1.4"
  label-md:
    fontFamily: "Cal Sans"
    fontSize: "24px"
    fontWeight: 400
    lineHeight: "1.3"
    letterSpacing: "-0.5px"
  body-sm:
    fontFamily: "Inter"
    fontSize: "16px"
    fontWeight: 400
    lineHeight: "1.5"
    color: "#404040"
  accent-serif:
    fontFamily: "Times New Roman"
    fontStyle: "italic"
    role: "legacy/incidental serif fallback, not a primary voice"
spacing:
  base: "4px"
  unit-sm: "8px"
  unit-md: "10px"
  unit-lg: "12px"
  unit-xl: "16px"
  gap: "24px"
  section-padding: "100px"
  section-gap: "162px"
rounded:
  control: "14px"
  card: "24px"
  card-lg: "48px"
  card-md: "20px"
  card-sm: "16px"
  pill: "100px"
components:
  button-primary-hero:
    background: "#FAF8F0"
    text-color: "#000000"
    radius: "100px"
    height: "44px"
    border: "none"
    note: "observed near-white/cream solid pill under hero headline"
  button-secondary-dark:
    background: "#033D4A"
    text-color: "#FFFFFF"
    radius: "14px"
    height: "40px"
  button-ghost-utility:
    background: "transparent"
    text-color: "#000000"
    radius: "14px"
    height: "40px"
    padding: "0px"
  card-photo-quad:
    background: "transparent"
    radius: "24px"
    padding: "0px"
    anatomy: "media-top-bleed, 2-tile stacked composition"
  card-destination-marquee:
    background: "transparent"
    radius: "24px"
    padding: "0px"
    shadow: "rgba(0, 0, 0, 0.25) 10px 11px 13px 0px"
    anatomy: "full-bleed photo with dark scrim footer label"
  card-story-tile:
    background: "transparent"
    radius: "16px"
    padding: "0px"
    anatomy: "media-top-bleed portrait photo, no caption overlay"
---
# Aerial Glass Wayfinder
Source: https://traavellio.framer.website/

## Overview
This is a bright, photo-led editorial travel system anchored by a full-bleed aerial hero, floating rounded photo tiles, and a deep-teal (`#033D4A`) heading ink standing in for near-black. It reads closer to Swiss-influenced editorial minimalism than to any dark-glass or bento convention: white page canvas dominates at roughly 38–60% of rendered pixels, Cal Sans display type carries hierarchy through scale rather than color, and the one saturated palette — turquoise ocean tones (~`#60C0D8`, `#60A8C0`, `#78C0D8`) — is confined entirely to photography, never to UI chrome. A single black section (~7% of the page) interrupts the white field mid-scroll to host a horizontal marquee and one large destination card, functioning as the system's only tonal inversion.

## Composition
The first screen is a full-viewport aerial ocean photograph with four corner-anchored photo tiles (rounded, drop-shadowed) framing a centered two-line display headline, a supporting sentence, one pill CTA, and a trust-metric row at the foot. Below the fold the page shifts to pure white: a two-column "about" band pairs stat copy and a dark ghost button with a stacked photo pair; then a labeled feature section presents an asymmetric four-column photo/text grid; then the black marquee band showcases one destination card sliding through a looping text ribbon; then a white social-proof band of uniform portrait tiles; the page closes on a second full-bleed photo band (palm/pool scene) carrying a closing headline, CTA, a scrolling icon-label ticker, and finally the dark footer. The deliberate choice is aerial/travel photography as the load-bearing visual (not illustration, not gradient mesh) — this rejects an abstract-gradient or bento-dashboard identity in favor of a documentary, destination-first read.

## Colors
`#FFFFFF` is the base page surface, covering the majority of scroll length and establishing an airy, editorial ground. `#000000` supplies one deliberate structural band (~7% of pixels) used only for the marquee/destination-card section and the footer — never for body content. `#033D4A` (declared ~3.1% area) is the semantic heading-ink role, used for all major headline and label text on white grounds in place of pure black, giving the type a cool, oceanic undertone that echoes the hero photography. `#404040`/`#545454`/`#7D7D7D` form a muted gray ramp for secondary and body copy. The turquoise cluster (`#60C0D8`, `#60A8C0`, `#78C0D8`, seen at ~4% each) is entirely photographic — ocean water in the hero — and is never extracted into buttons, borders, or backgrounds; this is the system's accent, rationed strictly to imagery. `#0000EE` is reserved for hyperlink-style text (footer link items). Nothing else carries color: buttons are black-on-transparent or cream-on-transparent, never tinted.

## Typography
Cal Sans is the exclusive display/label voice: 92px/600, -1.8px tracking for the hero display; 36px/400 for mid-page headlines; 24px/400 with -0.5px tracking for eyebrow-adjacent labels. Inter carries all reading copy: 20px/500 for supporting hero-adjacent sentences, 16px/400 (color `#404040`) for body paragraphs and card descriptions. There is no italic or serif voice in active use — Times New Roman appears only as an incidental fallback and should not be treated as a signature. Hierarchy is built purely through the Cal Sans/Inter size-and-weight contrast, not through color shifts, since headline ink and body ink sit close in the same cool-neutral family.

## Layout
Content is capped at a 1200px max-width, with 100px section padding and unusually generous 162px gaps between major sections, giving the page a slow, deliberate scroll rhythm despite dense photo content. The feature grid beneath the hero is asymmetric, not uniform: one row reads photo-tile / text+photo / photo-tile / text+photo, alternating media and caption columns across four tracks rather than repeating identical cards — a magazine-style split, not a card grid. The social-proof band is a uniform horizontal rail of equal-width portrait tiles (auto-scrolling), functioning as a scrolling rail rather than a fixed grid. Card radii step down by context: 24px on primary photo pairs and the destination card, 16px on the smaller story-rail tiles. The navbar and footer are true edge-to-edge (100% viewport width, 0px corner radii).

## Components
- **Navbar** — top of first screen only; edge-to-edge square bar, 72px tall, 100% viewport width (0/0 inset), all four corners 0px radius, sticky, transparent background; 1 nav item visible alongside a hamburger-style toggle beside the wordmark/icon lockup.
- **Button — hero primary** — centered under the hero headline; one instance; observed near-white/cream (`#FAF8F0`-family) solid pill, ~100px radius (full pill), paired with a small circular arrow-icon chip to its right.
- **Button — dark ghost (secondary)** — one instance in the "about" band; solid `#033D4A`-toned fill, white text, 14px radius (slightly-rounded), 40px height, paired with a circular icon affordance.
- **Button — utility/link CTA** — appears at the end of the feature-grid row and again on the closing photo band; transparent fill, black text, 14px radius, 40px height, 0px padding, paired with a circular arrow chip.
- **Card family — photo-pair (about section)** — ×2 stacked/paired; transparent background, 24–48px radius, 0px padding; each is a single full-bleed photograph with a heavy drop shadow (`rgba(0,0,0,0.25) 10px 11px 13px 0px`), no text overlay.
- **Card family — feature grid tiles** — ×4 across an asymmetric row; transparent, 24px radius, 0px padding; each pairs a rounded photo tile with adjacent (not overlaid) Cal Sans micro-heading and Inter body sentence beneath or beside it — media-top-bleed with a two-tile internal split per column.
- **Card — destination marquee card** — one large instance centered inside the black band, overlapping a looping horizontal text ribbon; transparent/photographic fill, 24px radius, drop shadow (`rgba(0,0,0,0.25) 10px 11px 13px 0px`); full-bleed photo covers ~85% of the card with a bottom-left label (place-name weight in Cal Sans) and a one-line Inter descriptor beneath it, plus a small circular arrow-icon affordance top-right.
- **Card family — story rail tiles** — a horizontal scrolling rail of ~8 uniform portrait photo tiles; transparent, 16px radius, 0px padding; pure media-top-bleed with no caption, silhouette/travel photography only.
- **Footer** — full-width black band, transparent fill; 13 links organized into four labeled columns (page links, documentation links, other pages, social icon row of 4); a closing credit line sits beneath a hairline divider.

## Graphics & Effects
A directional gradient scrim, `linear-gradient(114deg, rgba(5, 5, 5, 0.55) 0%, rgba(0, 0, 0, 0.05) 47.051%)`, darkens the lower-left corner of photographic media (used on the destination marquee card and similar image tiles) to preserve label legibility — it covers only that single card's photo area, not the page. A second gradient, `linear-gradient(rgb(255, 255, 255) 0% , rgba(255, 255, 255, 0) 100%)`, is a small top-fade mask (~0.6% of page) used to soften a photo edge into the white ground. Card elevation is carried by two shadow values: a soft ambient `rgba(89, 89, 89, 0.25) 0px 3px 15px 6px` on floating hero tiles, and a harder directional `rgba(0, 0, 0, 0.25) 10px 11px 13px 0px` on the larger photo-pair and destination cards; a hairline `rgb(0,0,0) 0px 0px 0px 1px inset` outlines select chips. Backdrop blur values of 2–5px appear on small floating UI chips (icon buttons, badges) for a light glass effect over photography. The hero and closing band use video as a live surface where photographic motion is implied — treat static aerial/pool photography as the fallback stand-in. No noise/grain or dot-pattern texture is present; texture comes entirely from photographic detail (water caustics, foliage, stone).

## Motion
Interactions are utilitarian and quick: width transitions run at `width 0.5s ease` for larger reveal/expand behavior and `width 0.1s linear` for snappy micro-adjustments; color transitions use `color 0.3s cubic-bezier(0.44, 0, 0.56, 1)` for text/icon state changes. A continuous `__framer-loading-spin` keyframe drives any loading-spinner affordance. The destination-card band and social-proof rail both auto-scroll horizontally (marquee behavior) via framer-motion, looping continuously without user input. Motion overall is brisk and mechanical rather than springy — no overshoot or bounce easing is present anywhere in the system.

## Guardrails
- Never tint UI chrome (buttons, nav, footer) with the turquoise water color — it exists only inside photography.
- Do not replace the black mid-page band with a gradient or color wash; it must stay a flat `#000000` interruption on an otherwise white page.
- Do not render the hero primary CTA as a glass/blurred button — it is a solid near-white/cream pill, not translucent.
- Keep the feature grid asymmetric (alternating photo/text columns); do not normalize it into equal-size uniform cards.
- Preserve the 0px-radius, edge-to-edge, transparent navbar — do not inset it or round its corners.
- Use `#033D4A` for headline ink on white grounds, not pure black, to keep the cool editorial tone.